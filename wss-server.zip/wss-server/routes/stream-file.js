var express = require('express');
var router = express.Router();

router.get('/stream-file', function(req, res, next) {
  res.render('stream-file', { title: 'WSS Server' });
});

router.get('/', function(req, res, next) {
  res.render('index', { title: 'WSS Server' });
});

module.exports = router;
