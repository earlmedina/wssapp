const express = require('express');
const router = express.Router();
const fs = require('fs');
const wss = require('../support/broadcast');
const upload = require('../support/upload');
const stream_data = wss.stream_data;
const send_data = wss.send_data;
const stream_file = wss.stream_file;
const clear_stream = wss.clear_stream;
var interval = wss.interval;

router.get('/', function(req, res, next) {
  clear_stream(interval);
  res.render('index', { title: 'WSS Server' });
});

router.post('/stream-text', (req, res) => {
	try {
    if (req.body.send==='send_once'){
        send_data(req.body.json_in);
        res.render('stream-text', { title: 'Send Status', status: 'Successful - event(s) sent once.' });
    } else {
        stream_data(req.body.json_in);
        res.render('stream-text', { title: 'Stream Status', status: 'Successful - streaming...' });
    }
  } catch (e) {
      res.render('stream-text', { title: 'Status', status: `${e.name} : ${e.message}` });
  }
});

router.post('/stream-file', upload.single('file-to-upload'), (req, res) => {
	let raw_data = fs.readFileSync(req.file.path,'utf8');
	try {
    if (req.body.send==='send_once'){
        send_data(raw_data);
        res.render('stream-file', { title: 'Send Status', status: 'Successful - event(s) sent once.' });
    } else {
        stream_data(raw_data);
        res.render('stream-file', { title: 'Stream Status', status: 'Successful - streaming...' });
    }
	} catch (e) {
      res.render('stream-file', { title: 'Status', status: `${e.name} : ${e.message}` });
	}
});

module.exports = router;
