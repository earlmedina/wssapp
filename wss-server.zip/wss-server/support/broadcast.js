const WebSocket = require('ws');
const http = require('http');
// const https = require('https');
const fs = require('fs');

const server = http.createServer();
// FOR SSL:
// const server = https.createServer({
//   cert: fs.readFileSync('/path/to/cert.crt'),
//   key: fs.readFileSync('/path/to/key.key')
// });

const wss = new WebSocket.Server({ server });
wss.on('connection', (ws) => {
	console.log('Client connected');
	ws.on('close', () => console.log('Client disconnected'));
});

var interval = null;

let send_to_clients = data => {
  wss.clients.forEach((client) => {
    data.forEach(function(entry){
      console.log("entry ",entry);
      client.send(JSON.stringify(entry));
    })  
  });
}

let prepare_data = json_in => {
  let data = JSON.parse(json_in);
  if (data.constructor !== Array) data = [data];
  return data;
}

let send_data = json_in => {
  let data = prepare_data(json_in);
  send_to_clients(data);
}

let stream_data = json_in => {
  let data = prepare_data(json_in);
  interval = setInterval(() => {
    send_to_clients(data);
  }, 1000);
}

let clear_stream = () => {
	clearInterval(interval);
}

server.listen(3001);
module.exports = {
	wss: wss,
	stream_data: stream_data,
  send_data: send_data,
	clear_stream: clear_stream,
	interval: interval
}